package anjocaido.minecraftmanager;









public class Main
{
  public Main() {}
  








  public static void main(String[] args)
  {
    new MinecraftBackupManager().setVisible(true);
  }
}
